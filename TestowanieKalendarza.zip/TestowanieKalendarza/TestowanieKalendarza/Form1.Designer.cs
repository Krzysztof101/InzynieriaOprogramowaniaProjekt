﻿namespace TestowanieKalendarza
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_wpisz = new System.Windows.Forms.TextBox();
            this.textBox_wypisz = new System.Windows.Forms.TextBox();
            this.button_wypisz = new System.Windows.Forms.Button();
            this.dataGridViewZmiany = new System.Windows.Forms.DataGridView();
            this.godziny = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dzien7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxImieNazw = new System.Windows.Forms.TextBox();
            this.textBoxDzien = new System.Windows.Forms.TextBox();
            this.textBoxGodzOd = new System.Windows.Forms.TextBox();
            this.textBoxGodzDo = new System.Windows.Forms.TextBox();
            this.buttonDodajWizyte = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxOtwarcie = new System.Windows.Forms.TextBox();
            this.textBoxZamkniecie = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.listBoxWizyty = new System.Windows.Forms.ListBox();
            this.buttonWypiszGrafik = new System.Windows.Forms.Button();
            this.textBoxCheck = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZmiany)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_wpisz
            // 
            this.textBox_wpisz.Location = new System.Drawing.Point(834, 524);
            this.textBox_wpisz.MaxLength = 10;
            this.textBox_wpisz.Name = "textBox_wpisz";
            this.textBox_wpisz.Size = new System.Drawing.Size(224, 22);
            this.textBox_wpisz.TabIndex = 0;
            // 
            // textBox_wypisz
            // 
            this.textBox_wypisz.Location = new System.Drawing.Point(834, 562);
            this.textBox_wypisz.MaxLength = 10;
            this.textBox_wypisz.Name = "textBox_wypisz";
            this.textBox_wypisz.Size = new System.Drawing.Size(195, 22);
            this.textBox_wypisz.TabIndex = 1;
            // 
            // button_wypisz
            // 
            this.button_wypisz.Location = new System.Drawing.Point(834, 594);
            this.button_wypisz.Name = "button_wypisz";
            this.button_wypisz.Size = new System.Drawing.Size(175, 52);
            this.button_wypisz.TabIndex = 2;
            this.button_wypisz.Text = "sprawdz date";
            this.button_wypisz.UseVisualStyleBackColor = true;
            this.button_wypisz.Click += new System.EventHandler(this.button_wypisz_Click);
            // 
            // dataGridViewZmiany
            // 
            this.dataGridViewZmiany.AllowUserToAddRows = false;
            this.dataGridViewZmiany.AllowUserToDeleteRows = false;
            this.dataGridViewZmiany.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewZmiany.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.godziny,
            this.dzien1,
            this.dzien2,
            this.dzien3,
            this.dzien4,
            this.dzien5,
            this.dzien6,
            this.dzien7});
            this.dataGridViewZmiany.Location = new System.Drawing.Point(12, 135);
            this.dataGridViewZmiany.Name = "dataGridViewZmiany";
            this.dataGridViewZmiany.RowHeadersWidth = 51;
            this.dataGridViewZmiany.RowTemplate.Height = 24;
            this.dataGridViewZmiany.Size = new System.Drawing.Size(789, 385);
            this.dataGridViewZmiany.TabIndex = 3;
            // 
            // godziny
            // 
            this.godziny.HeaderText = "godziny";
            this.godziny.MinimumWidth = 6;
            this.godziny.Name = "godziny";
            this.godziny.ReadOnly = true;
            this.godziny.Width = 125;
            // 
            // dzien1
            // 
            this.dzien1.HeaderText = "dzien1";
            this.dzien1.MinimumWidth = 6;
            this.dzien1.Name = "dzien1";
            this.dzien1.Width = 125;
            // 
            // dzien2
            // 
            this.dzien2.HeaderText = "dzien2";
            this.dzien2.MinimumWidth = 6;
            this.dzien2.Name = "dzien2";
            this.dzien2.Width = 125;
            // 
            // dzien3
            // 
            this.dzien3.HeaderText = "dzien3";
            this.dzien3.MinimumWidth = 6;
            this.dzien3.Name = "dzien3";
            this.dzien3.Width = 125;
            // 
            // dzien4
            // 
            this.dzien4.HeaderText = "dzien4";
            this.dzien4.MinimumWidth = 6;
            this.dzien4.Name = "dzien4";
            this.dzien4.Width = 125;
            // 
            // dzien5
            // 
            this.dzien5.HeaderText = "dzien5";
            this.dzien5.MinimumWidth = 6;
            this.dzien5.Name = "dzien5";
            this.dzien5.Width = 125;
            // 
            // dzien6
            // 
            this.dzien6.HeaderText = "dzien6";
            this.dzien6.MinimumWidth = 6;
            this.dzien6.Name = "dzien6";
            this.dzien6.Width = 125;
            // 
            // dzien7
            // 
            this.dzien7.HeaderText = "dzien7";
            this.dzien7.MinimumWidth = 6;
            this.dzien7.Name = "dzien7";
            this.dzien7.Width = 125;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(194, 20);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(102, 22);
            this.textBoxID.TabIndex = 4;
            // 
            // textBoxImieNazw
            // 
            this.textBoxImieNazw.Location = new System.Drawing.Point(194, 59);
            this.textBoxImieNazw.Name = "textBoxImieNazw";
            this.textBoxImieNazw.Size = new System.Drawing.Size(102, 22);
            this.textBoxImieNazw.TabIndex = 5;
            // 
            // textBoxDzien
            // 
            this.textBoxDzien.Location = new System.Drawing.Point(510, 23);
            this.textBoxDzien.Name = "textBoxDzien";
            this.textBoxDzien.Size = new System.Drawing.Size(102, 22);
            this.textBoxDzien.TabIndex = 6;
            // 
            // textBoxGodzOd
            // 
            this.textBoxGodzOd.Location = new System.Drawing.Point(510, 63);
            this.textBoxGodzOd.Name = "textBoxGodzOd";
            this.textBoxGodzOd.Size = new System.Drawing.Size(102, 22);
            this.textBoxGodzOd.TabIndex = 7;
            // 
            // textBoxGodzDo
            // 
            this.textBoxGodzDo.Location = new System.Drawing.Point(510, 103);
            this.textBoxGodzDo.Name = "textBoxGodzDo";
            this.textBoxGodzDo.Size = new System.Drawing.Size(102, 22);
            this.textBoxGodzDo.TabIndex = 8;
            // 
            // buttonDodajWizyte
            // 
            this.buttonDodajWizyte.Location = new System.Drawing.Point(674, 23);
            this.buttonDodajWizyte.Name = "buttonDodajWizyte";
            this.buttonDodajWizyte.Size = new System.Drawing.Size(98, 55);
            this.buttonDodajWizyte.TabIndex = 9;
            this.buttonDodajWizyte.Text = "dodaj wizyte";
            this.buttonDodajWizyte.UseVisualStyleBackColor = true;
            this.buttonDodajWizyte.Click += new System.EventHandler(this.buttonDodajWizyte_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "id -liczba calkowita";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "imie nazw - dowolny string";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(322, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(185, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "dzien - liczba calkowita 1 - 7";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(381, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "godz od";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(384, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "godz do";
            // 
            // textBoxOtwarcie
            // 
            this.textBoxOtwarcie.Location = new System.Drawing.Point(1135, 585);
            this.textBoxOtwarcie.Name = "textBoxOtwarcie";
            this.textBoxOtwarcie.Size = new System.Drawing.Size(146, 22);
            this.textBoxOtwarcie.TabIndex = 15;
            // 
            // textBoxZamkniecie
            // 
            this.textBoxZamkniecie.Location = new System.Drawing.Point(1135, 617);
            this.textBoxZamkniecie.Name = "textBoxZamkniecie";
            this.textBoxZamkniecie.Size = new System.Drawing.Size(130, 22);
            this.textBoxZamkniecie.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1132, 562);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 17);
            this.label6.TabIndex = 17;
            this.label6.Text = "godziny otwarcia";
            // 
            // listBoxWizyty
            // 
            this.listBoxWizyty.FormattingEnabled = true;
            this.listBoxWizyty.ItemHeight = 16;
            this.listBoxWizyty.Location = new System.Drawing.Point(1090, 261);
            this.listBoxWizyty.Name = "listBoxWizyty";
            this.listBoxWizyty.Size = new System.Drawing.Size(199, 196);
            this.listBoxWizyty.TabIndex = 18;
            // 
            // buttonWypiszGrafik
            // 
            this.buttonWypiszGrafik.Location = new System.Drawing.Point(1103, 166);
            this.buttonWypiszGrafik.Name = "buttonWypiszGrafik";
            this.buttonWypiszGrafik.Size = new System.Drawing.Size(186, 89);
            this.buttonWypiszGrafik.TabIndex = 19;
            this.buttonWypiszGrafik.Text = "button1";
            this.buttonWypiszGrafik.UseVisualStyleBackColor = true;
            this.buttonWypiszGrafik.Click += new System.EventHandler(this.buttonWypiszGrafik_Click);
            // 
            // textBoxCheck
            // 
            this.textBoxCheck.Location = new System.Drawing.Point(1103, 477);
            this.textBoxCheck.Name = "textBoxCheck";
            this.textBoxCheck.Size = new System.Drawing.Size(173, 22);
            this.textBoxCheck.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(650, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 17);
            this.label7.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(638, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(351, 17);
            this.label8.TabIndex = 22;
            this.label8.Text = "godziny wpisz w takim formacie jak liczby double w c++";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(638, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(285, 17);
            this.label9.TabIndex = 23;
            this.label9.Text = "jesli godzina ma być np. 10:30 to wpisz 10.5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1314, 732);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxCheck);
            this.Controls.Add(this.buttonWypiszGrafik);
            this.Controls.Add(this.listBoxWizyty);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxZamkniecie);
            this.Controls.Add(this.textBoxOtwarcie);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonDodajWizyte);
            this.Controls.Add(this.textBoxGodzDo);
            this.Controls.Add(this.textBoxGodzOd);
            this.Controls.Add(this.textBoxDzien);
            this.Controls.Add(this.textBoxImieNazw);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.dataGridViewZmiany);
            this.Controls.Add(this.button_wypisz);
            this.Controls.Add(this.textBox_wypisz);
            this.Controls.Add(this.textBox_wpisz);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewZmiany)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_wpisz;
        private System.Windows.Forms.TextBox textBox_wypisz;
        private System.Windows.Forms.Button button_wypisz;
        private System.Windows.Forms.DataGridView dataGridViewZmiany;
        private System.Windows.Forms.DataGridViewTextBoxColumn godziny;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dzien7;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxImieNazw;
        private System.Windows.Forms.TextBox textBoxDzien;
        private System.Windows.Forms.TextBox textBoxGodzOd;
        private System.Windows.Forms.TextBox textBoxGodzDo;
        private System.Windows.Forms.Button buttonDodajWizyte;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxOtwarcie;
        private System.Windows.Forms.TextBox textBoxZamkniecie;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBoxWizyty;
        private System.Windows.Forms.Button buttonWypiszGrafik;
        private System.Windows.Forms.TextBox textBoxCheck;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}

