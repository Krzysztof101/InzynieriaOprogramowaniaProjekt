﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;



namespace TestowanieKalendarza
{


    public partial class Form1 : Form
    {
        double godzinaOtwarciaGabinetu;
        double godzinaZamknieciaGabinetu;
        List<List<wizyta>> grafikWizyt;
        public void zapelnijKolumneGodzin(double godzinaOtwarcia, double godzinaZamkniecia, int ilosc_wierszy_DGVZmiany)
        {

            //int ilosc_wierszy_DGVZmiany = (int)Math.Round(((godzinaZamkniecia - godzinaOtwarcia) / 0.5));
            double g = godzinaOtwarcia;
            for (int i = 0; i < ilosc_wierszy_DGVZmiany; i++)
            {
                string godzina;
                if (g == Math.Floor(g))
                {
                    godzina = Convert.ToString(g) + ":00";
                }
                else
                {
                    godzina = Convert.ToString(g - 0.5) + ":30";
                }
                if (godzina.Length != 5)
                {
                    godzina = "0" + godzina;
                }

                string tekstKolumnyGodziny = godzina;
                tekstKolumnyGodziny += " - ";
                g += 0.5;
                if (g == Math.Floor(g))
                {
                    godzina = Convert.ToString(g) + ":00";
                }
                else
                {
                    godzina = Convert.ToString(g - 0.5) + ":30";
                }
                if (godzina.Length != 5)
                {
                    godzina = "0" + godzina;
                }
                tekstKolumnyGodziny += godzina;
                dataGridViewZmiany.Rows[i].Cells[0].Value = tekstKolumnyGodziny;

            }
        }
        public void zapelnijDGVWizyty()
        {
            double godzinaOtwarcia = godzinaOtwarciaGabinetu;
            double godzinaZamkniecia = godzinaZamknieciaGabinetu;
            dataGridViewZmiany.Rows.Clear();
            int iloscWierszy = (int)Math.Round((godzinaZamkniecia - godzinaOtwarcia) / 0.5);
            dataGridViewZmiany.Rows.Add(iloscWierszy);
            zapelnijKolumneGodzin(godzinaOtwarcia, godzinaZamkniecia, iloscWierszy);
            int kolorek = 0;
            for (int i = 0; i < grafikWizyt.Count; i++)
            {
                if(grafikWizyt.ElementAt(i).Count==0)
                {
                    continue;
                }

                //foreach (wizyta w in grafikWizyt.ElementAt(i))
                for(int k=0; k<grafikWizyt.ElementAt(i).Count;k++)
                {
                    wizyta w = grafikWizyt.ElementAt(i).ElementAt(k);
                    string wpis = Convert.ToString(w.pacj.id) + ", " + w.pacj.imieNazw;

                    int indeksWiersza = (int)Math.Round( (w.godzinaStartu - godzinaOtwarcia) / 0.5) ;
                    int ilePolGodzin = (int)Math.Round((w.godzinaZakonczenia - w.godzinaStartu) / 0.5);
                    dataGridViewZmiany.Rows[indeksWiersza].Cells[i + 1].Value = wpis;

                    if (kolorek == 0)
                    {
                        kolorek = 1;
                        for (int j = indeksWiersza; j < indeksWiersza + ilePolGodzin; j++)
                        {
                            dataGridViewZmiany.Rows[j].Cells[i + 1].Style.BackColor = Color.LightBlue;
                        }
                    }
                    else
                    {
                        kolorek = 0;
                        for (int j = indeksWiersza; j < indeksWiersza + ilePolGodzin; j++)
                        {
                            dataGridViewZmiany.Rows[j].Cells[i + 1].Style.BackColor = Color.LightGreen;
                        }
                    }
                }


            }


        }

        public Form1()
        {
            godzinaOtwarciaGabinetu = 9.5;
            godzinaZamknieciaGabinetu = 18.0;
            InitializeComponent();
            grafikWizyt = new List<List<wizyta>>();
            for(int i=0;i<7;i++)
            {
                List<wizyta> lista = new List<wizyta>();
                grafikWizyt.Add(lista);
                textBoxCheck.Text += "b";
            }
            textBoxCheck.Text += "a";

        }

        private void button_wypisz_Click(object sender, EventArgs e)
        {
            textBox_wypisz.Text = "";
            
            string dataTekst = textBox_wpisz.Text;

            string msg = "Wpisz datę w formacie YYYY:MM:DD";
            string cpt = "Niewłaściwy format daty";
            MessageBoxButtons btn = MessageBoxButtons.OK;
            DialogResult dlg;

            
            if (dataTekst.Length!=10)
            {
                dlg = MessageBox.Show(msg, cpt, btn);
                return;
            }
            /*
            for(int i=0;i<dataTekst.Length;i++)
            {
                if( (i == 4 || i== 7) && dataTekst[i] !=':' )
                {
                    dlg = MessageBox.Show(msg, cpt, btn);
                    return;
                }
                else if( (i!=4 && i!=7) && (dataTekst[i] < '0' || dataTekst[i] > '9') )
                {
                    msg = "hehehe";
                    dlg = MessageBox.Show(msg, cpt, btn);
                    return;
                }
            }
            */
            string rok;
            string miesiac;
            string dzien;
            rok = dataTekst.Substring(0, 4);
            miesiac = dataTekst.Substring(5, 2);
            dzien = dataTekst.Substring(8, 2);
            int rok_Liczba;
            int miesiac_Liczba;
            int dzien_Liczba;
            try
            {
                rok_Liczba = int.Parse(rok);
                miesiac_Liczba = int.Parse(miesiac);
                dzien_Liczba = int.Parse(dzien);
            }
            catch(  ArgumentException exc)
            {
                msg = "niewłaściwy format daty, parsowanie nieudane";
                dlg = MessageBox.Show(msg, cpt, btn);
                return;
            }
            DateTime DT;
            try
            {
                DT = new DateTime(rok_Liczba, miesiac_Liczba, dzien_Liczba, new GregorianCalendar());
            }
            catch(Exception ee)
            {
                msg = "niewłaściwy format daty, dzień lub miesiąc lub rok niewłaściwy";
                dlg = MessageBox.Show(msg, cpt, btn);
                return;
            }
            Calendar myCal = CultureInfo.InvariantCulture.Calendar;
            string rok2 = Convert.ToString(myCal.GetYear(DT));
            string miesiac2 = Convert.ToString(myCal.GetMonth(DT));
            string dzien2 = Convert.ToString(myCal.GetDayOfMonth(DT));
            textBox_wypisz.Text = dzien2 + ':' + miesiac2 + ':' + rok2; 


        }

        private void buttonDodajWizyte_Click(object sender, EventArgs e)
        {
            //NumberFormatInfo provider = new NumberFormatInfo();
            //provider.NumberDecimalSeparator = ", ";
            //provider.NumberGroupSeparator = ".";
            //provider.NumberGroupSizes = new int[] { 3 };

            double godzOd = Double.Parse(textBoxGodzOd.Text, System.Globalization.CultureInfo.InvariantCulture);
            double godzDo = Double.Parse(textBoxGodzDo.Text, System.Globalization.CultureInfo.InvariantCulture);
            int dzien = int.Parse(textBoxDzien.Text);
            Pacjent p = new Pacjent();
            p.id = int.Parse(textBoxID.Text);
            p.imieNazw = textBoxImieNazw.Text;
            wizyta w = new wizyta();
            w.dzien = dzien;
            w.godzinaStartu = godzOd;
            w.godzinaZakonczenia = godzDo;
            w.pacj = p;
            textBoxCheck.Text += "v";
            dodajWizyteDoGrafiku(w);



        }

        private void dodajWizyteDoGrafiku(wizyta w)
        {
            grafikWizyt.ElementAt(w.dzien - 1).Add(w);
            zapelnijDGVWizyty();    
            textBoxCheck.Text += "q";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            zapelnijDGVWizyty();
        }

        private void buttonWypiszGrafik_Click(object sender, EventArgs e)
        {
            listBoxWizyty.Items.Clear();

            foreach(List<wizyta> L in grafikWizyt)
            {
                if(L.Count==0)
                {
                    continue;
                }
                foreach(wizyta w in L)
                {
                    string rekord = Convert.ToString(w.dzien) + Convert.ToString(w.godzinaStartu) + Convert.ToString(w.godzinaZakonczenia) +
                        Convert.ToString(w.pacj.id) + w.pacj.imieNazw;
                    listBoxWizyty.Items.Add(rekord);

                }

            }
        }
    }

    public class Pacjent
    {
        public int id;
        public string imieNazw;
    }
    public class wizyta
    {
        public int dzien;
        public double godzinaStartu, godzinaZakonczenia;
        public Pacjent pacj;

    }


}
